.\objects\filter.o: ..\code\filter.c
.\objects\filter.o: ..\code\filter.h
.\objects\filter.o: E:\keil_v5_MDK_AND_C51\ARM\armComplier5\Bin\..\include\math.h
