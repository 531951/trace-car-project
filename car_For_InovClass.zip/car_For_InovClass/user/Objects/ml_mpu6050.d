.\objects\ml_mpu6050.o: ..\ml_libs\ml_mpu6050.c
.\objects\ml_mpu6050.o: ..\ml_libs\ml_mpu6050.h
.\objects\ml_mpu6050.o: E:\keil_v5_MDK_AND_C51\ARM\armComplier5\Bin\..\include\stdint.h
