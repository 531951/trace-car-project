.\objects\stm32f10x_i2c.o: ..\Library\stm32f10x_i2c.c
.\objects\stm32f10x_i2c.o: ..\Library\stm32f10x_i2c.h
.\objects\stm32f10x_i2c.o: ..\sys\stm32f10x.h
.\objects\stm32f10x_i2c.o: ..\sys\core_cm3.h
.\objects\stm32f10x_i2c.o: E:\keil_v5_MDK_AND_C51\ARM\armComplier5\Bin\..\include\stdint.h
.\objects\stm32f10x_i2c.o: ..\sys\system_stm32f10x.h
.\objects\stm32f10x_i2c.o: ..\Library\stm32f10x_rcc.h
