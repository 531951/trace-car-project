#include "headfile.h"
#include "HCSR04.h"
int main(void)
{
	/*???Ϊʲô����void�������ᱨ��?!*/
	
	OLED_Init();
	
	motor_init();
	encoder_init();
	
		motorA_duty(10000);
	 motorB_duty(10000);//success!
	delay_ms(500);
	void HCSR04_Start();

	

	
		

	uart_init(UART_1,115200,0);
	
	pid_init(&motorA, DELTA_PID, 10, 10, 5);
	pid_init(&motorB, DELTA_PID, 10, 10, 5);
	pid_init(&angle, POSITION_PID, 2, 0, 0.5);
	
	
	exti_init(EXTI_PB7,RISING,0);
	
	tim_interrupt_ms_init(TIM_3,10,0);
	while (1)
	{
		delay_ms(20);
				uint32_t lenth=HCSR04_GetValue();


	if(lenth<=100)
	{
			motorA_duty(10000);
		 motorB_duty(5000);//ת��
	}
	if(lenth>=500)
	{
				motorA_duty(30000);
	 motorB_duty(30000);//success!
	}

	} 
}
